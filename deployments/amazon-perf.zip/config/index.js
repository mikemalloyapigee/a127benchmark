var Management = require('volos-management-apigee');
var OAuth = require('volos-oauth-apigee');

exports.volos = {
  Management: Management,
  OAuth: OAuth
};
